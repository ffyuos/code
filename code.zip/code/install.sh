sudo apt-get update
sudo apt-get install mysql-server
sudo apt install openjdk-8-jre-headless
sudo service mysql start
sudo service mysql status
sudo mysql
