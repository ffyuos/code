# capstone-project-9900-w18q-gpass







You should follow this document to do installation on a lubuntu environment.



In the path same with this file, there are 3 files provided that are install.sh,create.sql and demo.jar



1. Make sure that there is not sql environment and any kind of java(jdk or jre) existing in this machine.

2. open a terminal and type the command "./install.sh",then it will update apt, install mysql and openjdk-8. It might take a few seconds to install.

3. It might ask for the password for lubuntu, so you should type the password.

4. When you are encountered with inquiries like "263MB of disk will be used,Do you want to continue?" You should type y and enter

5. When you saw information about mysql-sever like "started mysql Community server", it tells the sql and java are installed successfully and they have started the service.

6. You should type "q" to enter mysql terminal.

7. type  "source create.sql", it will install rename the password for the root, create database and create all the tables needed.

8. type "exit" to exit mysql terminal.

9. Type "java -jar demo.jar" to run the application.

10. You can enter the the main page with url http://localhost:8080/frontend/login.html



