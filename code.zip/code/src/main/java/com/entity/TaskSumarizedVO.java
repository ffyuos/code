package com.entity;

import com.entity.dao.Task;
import lombok.Data;

import java.io.Serializable;

@Data
public class TaskSumarizedVO implements Serializable {
    private int id;
    private String title;
    private String deadline;

    static public TaskSumarizedVO convertTaskTOVo(Task task){
        TaskSumarizedVO taskSumarizedVO = new TaskSumarizedVO();
        taskSumarizedVO.setId(task.getId());
        taskSumarizedVO.setTitle(task.getTitle());
        taskSumarizedVO.setDeadline(task.getDeadLine());
        return taskSumarizedVO;
    }
}
