package com.entity.dao;


import lombok.Data;

/**
 * Data class to abstract data object from mysql table "connection_list"
 */
@Data
public class ConnectionList {

    private static final long serialVersionUID = 1L;
    private int id;
    /**
     * id of the task master who receive a request
     */
    private int targetId;
    /**
     * id of the task master who send a request
     */
    private int fromId;
    /**
     * "statusCode" field of class @ConnectionStatus
     */
    private int flag;


    public ConnectionList(int id, int targetId, int fromId, int flag) {
        this.id = id;
        this.targetId = targetId;
        this.fromId = fromId;
        this.flag = flag;
    }

    public ConnectionList() {
    }

    public int getTargetId() {
        return targetId;
    }

    public void setTargetId(int targetId) {
        this.targetId = targetId;
    }

    public int getFromId() {
        return fromId;
    }

    public void setFromId(int fromId) {
        this.fromId = fromId;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public int getId() {
        return id;
    }
}
