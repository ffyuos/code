package com.entity.dao;


import com.entity.TaskMasterVO;
import lombok.Data;

import java.io.Serializable;
import java.util.Locale;

@Data
public class TaskMaster implements Serializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private String userName;
    private String email;
    private String passWord;
    private String tag;

    public TaskMaster(int id,String userName, String email, String passWord) {
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.passWord = passWord;
    }
    public TaskMaster(TaskMasterVO taskMasterVO){
        this.userName = taskMasterVO.getUserName();
        this.email = taskMasterVO.getEmail();
        this.passWord = taskMasterVO.getPassWord();
        StringBuilder s = new StringBuilder();
        for (String eachTag:taskMasterVO.getTag()){
            s.append(eachTag);
            s.append(",");
        }
        this.tag = s.substring(0,s.length()-1);
    }

    public  TaskMaster(){
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public String getEmail() {
        return email;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

}
