package com.entity;

import com.entity.dao.TaskMaster;

import java.io.Serializable;
import java.util.List;

/*
 This is class object we return to front-end in the most time because we don't wish to expost the id field to browser.
 */
public class TaskMasterVO implements Serializable {

    private String userName;
    private String email;
    private String passWord;
    private List<String> tag;

    public TaskMasterVO(String userName, String email, String passWord, List<String> tag) {
        this.userName = userName;
        this.email = email;
        this.passWord = passWord;
        this.tag = tag;
    }

    public TaskMasterVO(TaskMaster taskMaster){
        this.email = taskMaster.getEmail();
        this.userName = taskMaster.getUserName();
        this.passWord = null;
    }

    public TaskMasterVO(){

    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public List<String> getTag() {
        return tag;
    }

    public void setTag(List<String> tag) {
        this.tag = tag;
    }

    @Override
    public String toString() {
        return "TaskMasterVO{" +
                "userName='" + userName + '\'' +
                ", email='" + email + '\'' +
                ", passWord='" + passWord + '\'' +
                ", tag=" + tag +
                '}';
    }
}
