package com.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.dao.ConnectionList;
import org.apache.ibatis.annotations.Mapper;


/**
 * Interface to deal with sql statements extending the @BaseMapper that is provided by third party "mybatis-plus"
 */
@Mapper
public interface ConnectionListMapper extends BaseMapper<ConnectionList> {
}
