package com.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.entity.dao.Task;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaskMapper extends BaseMapper<Task> {
}
