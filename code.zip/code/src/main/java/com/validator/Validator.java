package com.validator;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.common.ConnectionStatus;
import com.common.TaskStatus;
import com.common.ValidateInfo;
import com.entity.dao.Task;
import com.entity.dao.TaskMaster;
import com.entity.TaskMasterVO;
import com.service.ConnectionListService;
import com.service.TaskMasterService;
import com.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

/*
    All kinds of varifying operations is here. Mostly it will return enum constant of @ValidateInfo
 */
@Component
public class Validator {

    @Autowired
    private TaskMasterService taskMasterService;

    @Autowired
    private ConnectionListService connectionListService;

    @Autowired
    private TaskService taskService;


    public ValidateInfo validateLogin(TaskMasterVO taskMasterVO){
        LambdaQueryWrapper<TaskMaster> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(TaskMaster::getEmail,taskMasterVO.getEmail());
        TaskMaster taskMaster = taskMasterService.getOne(queryWrapper);
        if(taskMaster == null){
            return ValidateInfo.Account_Not_Exist;
        }
        if(!taskMaster.getPassWord().equals(taskMasterVO.getPassWord())){
            return ValidateInfo.Wrong_Password;
        }
        return ValidateInfo.SUCCESS;
    }

    public ValidateInfo validateSign(TaskMasterVO taskMasterVO){
        TaskMaster taskMaster = taskMasterService.getTaskMasterByEmail(taskMasterVO.getEmail());
        if (taskMaster!=null){
            return ValidateInfo.Existing_Email;
        }
        StringBuilder s = new StringBuilder();
        for (String q: taskMasterVO.getTag()){
            s.append(q);
        }
        String mytag = s.toString();
        mytag = mytag.substring(0,mytag.length()-1);
        if(taskMasterVO.getEmail().length()>20 || taskMasterVO.getUserName().length()>20
                || taskMasterVO.getPassWord().length()>20 || mytag.length() > 20){
            return ValidateInfo.Toolong_Arguments;
        }
        return ValidateInfo.SUCCESS;
    }

    public ValidateInfo validateEditTaskMaster(TaskMaster taskMaster){
        if(taskMaster.getUserName().length()>20
                || taskMaster.getPassWord().length()>20){
            return ValidateInfo.Toolong_Arguments;
        }
        if(taskMaster.getTag()!=null && taskMaster.getTag().length()>20){
            return ValidateInfo.Toolong_Arguments;
        }
        return ValidateInfo.SUCCESS;
    }

    public ValidateInfo validateConnected(int id, String email){
        TaskMaster taskMaster = taskMasterService.getTaskMasterByEmail(email);
        if(taskMaster == null){
            return ValidateInfo.Account_Not_Exist;
        }
        if(taskMaster.getId() == id){
            return  ValidateInfo.CAN_NOT_CONNECT_YOURSELF;
        }
        boolean ifConnected = connectionListService.ifConnected(id, email);
        if(ifConnected){
            return ValidateInfo.ALREADY_CONNECTED;
        }
        boolean alreadySend = connectionListService.ifAlreadySendRequest(id,email);
        if(alreadySend){
            return ValidateInfo.ALREADY_SEND_REQUEST;
        }
        return ValidateInfo.SUCCESS;
    }

    public ValidateInfo validateConnectStatus(int id){
        ConnectionStatus connectionStatus = ConnectionStatus.getStatusBy(id);
        if(connectionStatus == ConnectionStatus.WRONG){
            return ValidateInfo.WORNG_CONNECT_STATUS_CODE;
        }
        return ValidateInfo.SUCCESS;
    }

    public ValidateInfo validateTask(Task task){
        if(task.getTitle() == null || task.getTitle().length() >50){
            return ValidateInfo.WORNG_TITLE;
        }
        if(task.getDescription() == null || task.getDescription().length() > 100){
            return ValidateInfo.WORNG_TASK_DESCRIPTION;
        }
        if(task.getTag()!=null){
            if(task.getTag().length() > 20){
                return ValidateInfo.WRONG_TASK_TAG;
            }
        }
        for(TaskStatus taskStatus: TaskStatus.values()){
            if(task.getTaskStatus() == taskStatus.getId()){
                return ValidateInfo.SUCCESS;
            }
        }
        return ValidateInfo.WRONG_TASK_STATUS_CODE;
    }

    public ValidateInfo validateUpdateTask(Task task){
        Task task1 = taskService.getById(task.getId());
        if(Objects.isNull(task1)){
            return ValidateInfo.TASK_NOT_EXIST;
        }
        if(task1.getTaskStatus()==TaskStatus.COMPLETED.getId()){
            return ValidateInfo.CAN_NOT_UPDATE_COMPLETED_TASK;
        }
        return validateTask(task);
    }

    public ValidateInfo validateTaskMaster(int id){
        TaskMaster taskMaster = taskMasterService.getById(id);
        if(taskMaster == null){
            return ValidateInfo.Account_Not_Exist;
        }
        return ValidateInfo.SUCCESS;
    }
}
