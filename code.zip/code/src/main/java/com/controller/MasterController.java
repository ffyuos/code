package com.controller;

import com.common.Response;
import com.common.ValidateInfo;
import com.entity.dao.TaskMaster;
import com.entity.TaskMasterVO;
import com.validator.Validator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import com.service.TaskMasterService;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Locale;

@Slf4j
@RestController
@CrossOrigin
@RequestMapping("/master")
public class MasterController {

    @Autowired
    private TaskMasterService masterService;
    @Autowired
    private Validator validator;
    /**
     * This is api for a user to login
     * @param httpServletRequest
     * @param taskMasterVO
     * @return
     */
    @PostMapping("/login")
    public Response<TaskMaster> login(HttpServletRequest httpServletRequest, @RequestBody TaskMasterVO taskMasterVO,
                                        HttpServletResponse httpServletResponse){
        log.info(taskMasterVO.toString());
        ValidateInfo validateInfo = validator.validateLogin(taskMasterVO);
        if(validateInfo.getCode() == ValidateInfo.SUCCESS.getCode()){
            TaskMaster taskMaster = masterService.getTaskMasterByEmail(taskMasterVO.getEmail());
            taskMaster.setPassWord(null);
            Cookie cookie = new Cookie("userid",String.valueOf(taskMaster.getId()));
            cookie.setPath(httpServletRequest.getContextPath()+"/");
            cookie.setMaxAge(3600);
            httpServletResponse.addCookie(cookie);
            return Response.success(taskMaster);
        }
        return Response.error(validateInfo.getInfo(),validateInfo.getCode());
    }

    /**
     *This is api for a user to sign in, he/she needs to send a TaskMasterVO object to this api.
     * @param taskMasterVO
     * @return ResponseInfo
     */
    @PostMapping("/enroll")
    @Transactional
    public Response<TaskMaster> sign(@RequestBody TaskMasterVO taskMasterVO){
        log.info(taskMasterVO.toString());
        ValidateInfo validateInfo = validator.validateSign(taskMasterVO);
        if(validateInfo.getCode()!=0){
            return Response.error(validateInfo.getInfo(),validateInfo.getCode());
        }
        TaskMaster taskMaster = masterService.saveTaskMaster(taskMasterVO);
        if(taskMaster == null){
            return Response.error(ValidateInfo.Service_Save_Error.getInfo(), ValidateInfo.Service_Save_Error.getCode());
        }
        return Response.success(null);
    }


    /**
     * get personal information about using his/her own id.
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public Response<TaskMaster> getById(@PathVariable("id") Integer id){
        TaskMaster taskMaster = masterService.getById(id);
        if(taskMaster == null){
            return Response.error(ValidateInfo.Account_Not_Exist.getInfo(),ValidateInfo.Account_Not_Exist.getCode());
        }
        return Response.success(taskMaster);
    }

    /**
     * api to update a task master's information
     * @param taskMaster
     * @return
     */
    @PostMapping("/edit")
    public Response<TaskMaster> edit(@RequestBody TaskMaster taskMaster){
        Integer id = taskMaster.getId();
        TaskMaster taskMasterchange = masterService.getById(id);
        if(taskMasterchange == null){
            return Response.error(ValidateInfo.Account_Not_Exist.getInfo(),ValidateInfo.Account_Not_Exist.getCode());
        }
        ValidateInfo validateInfo = validator.validateEditTaskMaster(taskMaster);
        if(validateInfo!=ValidateInfo.SUCCESS){
            return Response.error(validateInfo);
        }
        taskMasterchange.setUserName(taskMaster.getUserName());
        taskMasterchange.setPassWord(taskMaster.getPassWord());
        taskMasterchange.setEmail(taskMasterchange.getEmail());
        taskMasterchange.setTag(taskMaster.getTag());
        boolean flag = masterService.updateById(taskMasterchange);
        if(!flag){
            return Response.error(ValidateInfo.Service_Save_Error.getInfo(), ValidateInfo.Service_Save_Error.getCode());
        }
        return Response.success();
    }


    /**
     * api to logout
     * @param httpServletRequest
     * @return
     */
    @PostMapping("/logout")
    public Response<String> logout(HttpServletRequest httpServletRequest){
        httpServletRequest.getSession().removeAttribute("id");
        return Response.success("Success");
    }

}
