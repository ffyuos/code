package com.controller;


import com.common.Response;
import com.common.ValidateInfo;
import com.entity.ConnectionVO;
import com.entity.dao.Task;
import com.entity.dao.TaskMaster;
import com.service.ConnectionListService;
import com.service.TaskMasterService;
import com.validator.Validator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


/**
 * This is controller level class for front-end devleopers to use, it involves getting connectd master list, sending
 * connection request, dealing with request from others.
 */
@Slf4j
@RestController
@CrossOrigin
@RequestMapping("/master")
public class MasterConnectionController {

    @Autowired
    private TaskMasterService taskMasterService;

    @Autowired
    private ConnectionListService connectionListService;

    @Autowired
    private Validator validator;

    /**
     * This is api for getting the connected master list using the master id.
     * @param id This master's id
     * @return Response<List<ConnectionVO>>
     */
    @GetMapping(value = "/connected/{id}")
    public Response<List<ConnectionVO>> getAllConnected(@PathVariable("id") Integer id){
        List<ConnectionVO> allConnected = connectionListService.getAllConnected(id);
        return Response.success(allConnected);
    }

    /**
     * This is api for recommending the connected task masters. When creating a task or updating task, if a task master
     * is going to assign this task a new master, then he/she would send his/her id and the task object for the backend
     * to analyse which connected master is more qualified to do this.
     * @param id
     * @param task
     * @return Response<List<ConnectionVO>>
     */
    @PostMapping(value = "/connected/sorted/{id}")
    public Response<List<ConnectionVO>> getRecommendingMaster(@PathVariable("id") Integer id, @RequestBody Task task){
        List<ConnectionVO> allConnected = connectionListService.getAllConnected(id);
        allConnected.sort(new Comparator<ConnectionVO>() {
            @Override
            public int compare(ConnectionVO o1, ConnectionVO o2) {
                return o1.getBusylevel() - o2.getBusylevel();
            }
        });
        List<TaskMaster> taskMasters = new ArrayList<>();
        if(task.getTag()!=null){
            taskMasters = taskMasterService.searchByTag(task.getTag());
        }
        List<Integer> masterIdByTag = taskMasters.stream().map(TaskMaster::getId).collect(Collectors.toList());

        List<ConnectionVO> res = allConnected.stream().filter(x->masterIdByTag.contains(x.getId())).collect(Collectors.toList());
        allConnected.removeAll(res);
        res.addAll(allConnected);
        return Response.success(res);
    }


    /**
     * This is api for a master to get all his/her unresolved connection request from others.
     * @param id
     * @return
     */
    @GetMapping(value = "/unresolved/{id}")
    public Response<List<ConnectionVO>> getAllUnResolved(@PathVariable("id") String id){
        Integer iid = Integer.parseInt(id);
        List<ConnectionVO> allUnresolved = connectionListService.getAllUnresolved(iid);
        return Response.success(allUnresolved);
    }

    /**
     * This is api for a task master to connect his/her collaborators, the email of the connected task master is need for
     * the second argument of this api.
     * @param id
     * @param email
     * @return
     */
    @PostMapping(value = "/connect")
    public Response<String> connect(@RequestParam String id,@RequestParam String email){
        int iid = Integer.parseInt(id);
        ValidateInfo validateInfo = validator.validateConnected(iid,email);
        if(validateInfo != ValidateInfo.SUCCESS){
            return Response.error(validateInfo.getInfo(),validateInfo.getCode());
        }

        boolean flag = connectionListService.connect(iid,email);
        if(!flag){
            return Response.error(validateInfo.getInfo(),validateInfo.getCode());
        }
        return Response.success("Success");
    }

    /**
     * When receiving a request from another, the task master would know id of the task master sending request, that will
     * be fromid in the function, he will use his own id as targetid, and status code to decide if he/she accept or decline
     * the request.
     * @param targetid
     * @param fromid
     * @param status
     * @return
     */
    @PostMapping("/dealrequest")
    public Response<String> dealRequest(@RequestParam String targetid, @RequestParam String fromid, @RequestParam String status){
        ValidateInfo validateInfo = validator.validateConnectStatus(Integer.parseInt(status));
        if(validateInfo!=ValidateInfo.SUCCESS){
            return Response.error(validateInfo);
        }
        boolean flag = connectionListService.updateConnectStatus(targetid, fromid,status);
        if(!flag){
            return Response.error(ValidateInfo.Service_Save_Error.getInfo(), ValidateInfo.Service_Save_Error.getCode());
        }
        return Response.success();
    }

}
