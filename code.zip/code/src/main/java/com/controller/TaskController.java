package com.controller;


import com.common.Response;
import com.common.TaskStatus;
import com.common.ValidateInfo;
import com.entity.TaskSumarizedVO;
import com.entity.dao.Task;
import com.service.TaskService;
import com.validator.Validator;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@RestController
@CrossOrigin
@RequestMapping("/task")
public class TaskController {


    @Autowired
    TaskService taskService;

    @Autowired
    Validator validator;

    /**
     * api to create a task
     * @param task
     * @return
     */
    @PostMapping("/create")
    public Response<String> createTask(@RequestBody Task task){
        ValidateInfo validateInfo = validator.validateTask(task);
        if(validateInfo != ValidateInfo.SUCCESS){
            return Response.error(validateInfo);
        }
        boolean  flag = taskService.createTask(task);
        if(!flag){
            return Response.error(ValidateInfo.Service_Save_Error);
        }
        return Response.success();
    }

    /**
     * api to updating a task
     * @param task
     * @return
     */
    @PutMapping("/update")
    public Response<String> updateTask(@RequestBody Task task){
        ValidateInfo validateInfo = validator.validateUpdateTask(task);
        if(validateInfo != ValidateInfo.SUCCESS){
            return Response.error(validateInfo);
        }
        if(task.getDeadLine() == null){
            task.setDeadLine(null);
        }
        Task task1 = taskService.getById(task.getId());
        task.setCreatedTime(task1.getCreatedTime());
        if(task1.getTaskStatus() != TaskStatus.COMPLETED.getId()){
            if(task.getTaskStatus() == TaskStatus.COMPLETED.getId()){
                long mills = System.currentTimeMillis();
                Date date = new Date(mills);
                task.setFinishedTime(date.toString());
            }
        }
        boolean flag = taskService.saveOrUpdate(task);
        if(!flag){
            return Response.error(ValidateInfo.Service_Save_Error);
        }
        return Response.success();
    }

    /**
     * api to getting own task list
     * @param id master'id
     * @return
     */
    @GetMapping("/master/self/{id}")
    public Response<List<Task>> getOwnTasks(@PathVariable Integer id){
        ValidateInfo validateInfo = validator.validateTaskMaster(id);
        if(validateInfo!= ValidateInfo.SUCCESS){
            return Response.error(validateInfo);
        }
        List<Task> taskListsByMasterId = taskService.getTaskListsByMasterId(id);
        return Response.success(taskListsByMasterId);
    }

    /**
     * api to get connected masters' task lists.
     * @param id
     * @return
     */
    @GetMapping("/master/others/{id}")
    public Response<List<TaskSumarizedVO>> getOthersTask(@PathVariable Integer id){
        ValidateInfo validateInfo = validator.validateTaskMaster(id);
        if(validateInfo!= ValidateInfo.SUCCESS){
            return Response.error(validateInfo);
        }
        List<Task> taskListsByMasterId = taskService.getTaskListsByMasterId(id);
        List<TaskSumarizedVO> taskSumarizedVOList = taskListsByMasterId.stream().map(TaskSumarizedVO::convertTaskTOVo).collect(Collectors.toList());
        return Response.success(taskSumarizedVOList);
    }

    /**
     * This is api for novel fucntions, this will predict the deadline for a specified task.
     * @param task
     * @return
     */
    @SneakyThrows
    @PostMapping("/deadline/predict")
    public Response<String> getPredicate(@RequestBody Task task){
        List<Task> search = new ArrayList<>();
        if(task.getTitle()!=null || task.getDescription()!=null || task.getTag()!=null){
            search = taskService.search(task.getTitle(), task.getDescription(), task.getTag());
        }
        List<Task> mytag = taskService.getTaskListsByMasterId(task.getTaskOwner());
        long finishedPeriodForSearchTasks = 0;
        long finishedCountForSearchTasks = 0;
        for(Task task1 : search){
            if(task1.getFinishedTime()!=null){
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                java.util.Date createTime =  sdf.parse(task1.getCreatedTime());
                java.util.Date finishedTime = sdf.parse(task1.getFinishedTime());
                long diff = finishedTime.getTime() - createTime.getTime();
                TimeUnit time  = TimeUnit.DAYS;
                long difference  = time.convert(diff,TimeUnit.MILLISECONDS);
                finishedPeriodForSearchTasks += difference;
                finishedCountForSearchTasks++;
            }
        }
        long searchTaskDuration = 0;
        if(finishedCountForSearchTasks!=0){
            searchTaskDuration = finishedPeriodForSearchTasks/finishedCountForSearchTasks;
        }
        long finishedPeriodForOwnerTasks = 0;
        long finishedCountForOwnerTasks =0;
        for(Task task1 : mytag){
            if(task1.getFinishedTime()!=null){
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                java.util.Date createTime =  sdf.parse(task1.getCreatedTime());
                java.util.Date finishedTime = sdf.parse(task1.getFinishedTime());
                long diff = finishedTime.getTime() - createTime.getTime();
                TimeUnit time  = TimeUnit.DAYS;
                long difference  = time.convert(diff,TimeUnit.MILLISECONDS);
                finishedPeriodForOwnerTasks += difference;
                finishedCountForOwnerTasks++;
            }
        }
        long ownTaskDuration = 0;
        if(finishedCountForOwnerTasks!=0){
            ownTaskDuration = finishedPeriodForOwnerTasks/finishedCountForOwnerTasks;
        }
        double v =0;
        if(ownTaskDuration != 0 && searchTaskDuration!=0){
            v = 0.5 * ownTaskDuration + 0.5 * searchTaskDuration;
        }else{
            v = ownTaskDuration!=0?ownTaskDuration:searchTaskDuration;
        }

        int iv =(int)v;
        if(iv == 0){
            if(finishedCountForOwnerTasks==0 && finishedCountForSearchTasks ==0){
                iv = 7;
            }else{
                iv = 1;
            }
        }
        String taskCreatedTime = null;
        if(task.getCreatedTime()!=null){
            taskCreatedTime = task.getCreatedTime();
        }else{
            long mills = System.currentTimeMillis();
            Date date = new Date(mills);
            taskCreatedTime = date.toString();
        }
        LocalDate localDate = LocalDate.parse(taskCreatedTime);
        localDate = localDate.plusDays(iv);
        return Response.success(localDate.toString());
    }

    /**
     * search a task by using some keywords
     * @param id task master id
     * @param taskid task id not compulsory
     * @param title title of the task not compulsory
     * @param description description of the task not compulsory
     * @param deadline deadline of the task not compulsory
     * @return
     */
    @GetMapping("/{id}/search")
    public Response<List<Task>> searchTasks(@PathVariable Integer id, @RequestParam(required = false) String taskid,@RequestParam(required = false) String title,@RequestParam(required = false) String description,@RequestParam(required = false) String deadline){
        List<Task> list = taskService.search(id,taskid,title,description,deadline);
        return Response.success(list);
    }

}
