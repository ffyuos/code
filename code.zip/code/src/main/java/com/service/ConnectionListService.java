package com.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.entity.ConnectionVO;
import com.entity.dao.ConnectionList;

import java.util.List;
/**
 * Interface for business layer about class @ConnectionList
 */
public interface ConnectionListService extends IService<ConnectionList> {
    public List<ConnectionVO> getAllConnected(int id);
    public List<ConnectionVO> getAllUnresolved(int id);
    public boolean ifConnected(int id, String email);
    public boolean connect(int id,String email);

    boolean updateConnectStatus(String targetId, String fromId, String status);

    boolean ifAlreadySendRequest(int id, String email);
}
