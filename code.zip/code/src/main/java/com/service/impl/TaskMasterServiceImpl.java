package com.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.entity.TaskMasterVO;
import com.mapper.TaskMasterMapper;
import com.entity.dao.TaskMaster;
import com.service.TaskMasterService;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * CRUD operations about TaskMaster data layer.
 */
@Service
public class TaskMasterServiceImpl extends ServiceImpl<TaskMasterMapper, TaskMaster> implements TaskMasterService {

    private final String tag_field = "tag";
    @Override
    public TaskMaster getTaskMasterByEmail(String email) {
        LambdaQueryWrapper<TaskMaster> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(TaskMaster::getEmail,email);
        return getOne(queryWrapper);
    }

    @Override
    public TaskMaster saveTaskMaster(TaskMasterVO taskMasterVO) {
        boolean flag = save(new TaskMaster(taskMasterVO));
        if(!flag){
            return null;
        }
        return getTaskMasterByEmail(taskMasterVO.getEmail());
    }

    @Override
    public List<TaskMaster> searchByTag(String tag) {
        QueryWrapper<TaskMaster> queryWrapper = new QueryWrapper<>();
        queryWrapper.like(tag_field,tag);
        return this.baseMapper.selectList(queryWrapper);
    }
}
