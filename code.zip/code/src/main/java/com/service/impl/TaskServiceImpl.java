package com.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.common.TaskStatus;
import com.entity.ConnectionVO;
import com.entity.dao.Task;
import com.mapper.TaskMapper;
import com.service.TaskMasterService;
import com.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * CRUD operations about Taskdata layer.
 */
@Service
public class TaskServiceImpl extends ServiceImpl<TaskMapper, Task> implements TaskService {


    @Autowired
    private TaskMasterService taskMasterService;

    @Autowired
    private ConnectionListImpl connectionListService;

    private final String owner = "task_owner";

    private final String titleCol = "title";

    private final String descprtionCol = "description";

    private final String taskIdCol = "id";

    private final String deadLineCol = "dead_line";

    private final String status = "task_status";

    @Override
    public boolean createTask(Task task) {
       long mills = System.currentTimeMillis();
       Date date = new Date(mills);
       task.setCreatedTime(date.toString());
       boolean b = save(task);
       return b;
    }

    @Override
    public List<Task> getTaskListsByMasterId(Integer id) {
        QueryWrapper<Task> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(owner,id);
        List<Task> list =  this.baseMapper.selectList(queryWrapper);
        list.sort(new Comparator<Task>() {
            @Override
            public int compare(Task o1, Task o2) {
                if(o1.getDeadLine() == null && o2.getDeadLine() == null) {
                    return 0;
                }
                if(o1.getDeadLine() == null){
                    return 1;
                }
                if(o2.getDeadLine() == null){
                    return -1;
                }
                return o1.getDeadLine().compareTo(o2.getDeadLine());
            }
        });
        return list;
    }

    @Override
    public Integer getBusyLevelById(Integer id) {
        QueryWrapper<Task> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(owner,id);
        queryWrapper.ne(status, TaskStatus.COMPLETED.getId());
        int listCount = this.baseMapper.selectCount(queryWrapper);
        if(listCount == 0){
            return 0;
        }else if(listCount<=1){
            return 30;
        } else if( listCount <= 2){
            return 50;
        }else if(listCount <= 3){
            return 70;
        }else if(listCount <=4){
            return 100;
        }else{
            return 110;
        }
    }

    @Override
    public List<Task> search(Integer id, String taskid, String title, String description, String deadline) {
        List<ConnectionVO> allConnected = connectionListService.getAllConnected(id);
        List<Integer> masterId = allConnected.stream().map(ConnectionVO::getId).collect(Collectors.toList());
        masterId.add(id);
        QueryWrapper<Task> queryWrapper = new QueryWrapper<>();
        if(taskid!= null){
            queryWrapper.eq(taskIdCol,Integer.parseInt(taskid));
        }
        if(title != null){
            queryWrapper.like(titleCol,title);
        }
        if(description!= null){
            queryWrapper.like(descprtionCol,description);
        }
        if(deadline!=null){
            queryWrapper.like(deadLineCol,deadline);
        }
//        System.out.println(queryWrapper.getTargetSql());
        List<Task> list = baseMapper.selectList(queryWrapper);
        List<Task> tasks = list.stream().filter(task -> masterId.contains(task.getTaskOwner())).collect(Collectors.toList());
        return tasks;
    }


    @Override
    public List<Task> search(String title, String description, String tag) {
        QueryWrapper<Task> queryWrapper = new QueryWrapper<>();
        if(title != null){
            queryWrapper.like(titleCol,title);
        }
        if(description!= null){
            queryWrapper.like(descprtionCol,description);
        }
        if(tag!= null){
            queryWrapper.like(descprtionCol,tag);
        }
//        System.out.println(queryWrapper.getTargetSql());
        List<Task> list = baseMapper.selectList(queryWrapper);
        return list;
    }
}
