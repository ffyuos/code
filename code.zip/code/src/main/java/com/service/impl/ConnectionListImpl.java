package com.service.impl;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.common.ConnectionStatus;
import com.entity.ConnectionVO;
import com.entity.dao.ConnectionList;
import com.entity.dao.TaskMaster;
import com.mapper.ConnectionListMapper;
import com.service.ConnectionListService;
import com.service.TaskMasterService;
import com.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * CRUD operations about ConnectionList data layer.
 *
 */
@Service
public class ConnectionListImpl extends ServiceImpl<ConnectionListMapper, ConnectionList> implements ConnectionListService {

    @Autowired
    private TaskMasterService taskMasterService;


    @Autowired
    private ConnectionListMapper connectionListMapper;


    @Autowired
    private TaskService taskService;

    @TableField("tagetId")
    private String targetId = "target_id";

    @TableField("fromId")
    private String fromId = "from_id";

    @TableField("flag")
    private String status = "flag";

    @Override
    public List<ConnectionVO> getAllConnected(int id) {
        QueryWrapper<ConnectionList> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(targetId,id);
        queryWrapper.eq(status, ConnectionStatus.accepted.getStatusCode());
        List<ConnectionList> connectionLists = connectionListMapper.selectList(queryWrapper);
        QueryWrapper<ConnectionList> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq(fromId,id);
        queryWrapper1.eq(status, ConnectionStatus.accepted.getStatusCode());
        connectionLists.addAll(connectionListMapper.selectList(queryWrapper1));
        List<ConnectionVO> connectionVOList = new ArrayList<>();
        for(ConnectionList connectionList: connectionLists){
            int idConnected = connectionList.getFromId() == id?connectionList.getTargetId():connectionList.getFromId();
            TaskMaster taskMaster = taskMasterService.getById(idConnected);
            ConnectionVO connectionVO = new ConnectionVO();
            connectionVO.setId(taskMaster.getId());
            connectionVO.setUsername(taskMaster.getUserName());
            connectionVO.setEmail(taskMaster.getEmail());
            connectionVOList.add(connectionVO);
            connectionVO.setBusylevel(taskService.getBusyLevelById(idConnected));
        }
        return connectionVOList;
    }

    @Override
    public List<ConnectionVO> getAllUnresolved(int id) {
        QueryWrapper<ConnectionList> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(targetId,id);
        queryWrapper.eq(status,ConnectionStatus.unresolved.getStatusCode());
        System.out.println(queryWrapper.getTargetSql());
        List<ConnectionList> connectionLists = connectionListMapper.selectList(queryWrapper);
        List<ConnectionVO> connectionVOList = new ArrayList<>();
        for(ConnectionList connectionList: connectionLists){
            int idConnected = connectionList.getFromId() == id?connectionList.getTargetId():connectionList.getFromId();
            TaskMaster taskMaster = taskMasterService.getById(idConnected);
            ConnectionVO connectionVO = new ConnectionVO();
            connectionVO.setId(taskMaster.getId());
            connectionVO.setUsername(taskMaster.getUserName());
            connectionVO.setEmail(taskMaster.getEmail());
            connectionVOList.add(connectionVO);
        }
        return connectionVOList;
    }

    @Override
    public boolean ifConnected(int id, String email) {
        TaskMaster taskMaster = taskMasterService.getTaskMasterByEmail(email);
        QueryWrapper<ConnectionList> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(fromId,id);
        queryWrapper.eq(targetId,taskMaster.getId());
        queryWrapper.eq(status,ConnectionStatus.accepted.getStatusCode());
        ConnectionList connectionList = connectionListMapper.selectOne(queryWrapper);
        if(connectionList!=null){
            return true;
        }
        QueryWrapper<ConnectionList> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq(fromId,taskMaster.getId());
        queryWrapper1.eq(targetId,id);
        queryWrapper1.eq(status,ConnectionStatus.accepted.getStatusCode());
        ConnectionList connectionList1 = connectionListMapper.selectOne(queryWrapper1);
        if(connectionList1 != null){
            return true;
        }
        return false;
    }

    @Override
    public boolean connect(int id, String email) {
        TaskMaster taskMaster = taskMasterService.getTaskMasterByEmail(email);
        ConnectionList connectionList = new ConnectionList();
        connectionList.setFromId(id);
        connectionList.setTargetId(taskMaster.getId());
        connectionList.setFlag(ConnectionStatus.unresolved.getStatusCode());
        boolean connect = save(connectionList);
        return connect;
    }

    @Override
    public boolean updateConnectStatus(String targetId, String fromId, String status) {
        Integer targetid = Integer.parseInt(targetId);
        Integer fromid = Integer.parseInt(fromId);
        Integer flag = Integer.parseInt(status);
        QueryWrapper<ConnectionList> connectionListQueryWrapper = new QueryWrapper<>();
        connectionListQueryWrapper.eq(this.fromId,fromid);
        connectionListQueryWrapper.eq(this.targetId,targetid);
        connectionListQueryWrapper.eq(this.status,ConnectionStatus.unresolved.getStatusCode());
        ConnectionList connectionList = connectionListMapper.selectOne(connectionListQueryWrapper);
        connectionList.setFlag(flag);
        return saveOrUpdate(connectionList);
    }

    @Override
    public boolean ifAlreadySendRequest(int id, String email) {
        TaskMaster taskMaster = taskMasterService.getTaskMasterByEmail(email);
        QueryWrapper<ConnectionList> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(fromId,id);
        queryWrapper.eq(targetId,taskMaster.getId());
        queryWrapper.eq(status,ConnectionStatus.unresolved.getStatusCode());
        ConnectionList connectionList = connectionListMapper.selectOne(queryWrapper);
        if(connectionList!=null){
            return true;
        }
        return false;
    }
}
