package com.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.entity.dao.Task;

import java.util.List;

/**
 * Interface for business layer about class Task
 */
public interface TaskService extends IService<Task> {

    public  boolean createTask(Task task);

    public List<Task> getTaskListsByMasterId(Integer id);

    public Integer getBusyLevelById(Integer id);

    List<Task> search(Integer id, String taskid, String title, String description, String deadline);

    public List<Task> search(String title, String description, String tag);
}
