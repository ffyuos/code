package com.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.entity.dao.TaskMaster;
import com.entity.TaskMasterVO;

import java.util.List;

/**
 * Interface for business layer about class @TaskMaster
 */
public interface TaskMasterService extends IService<TaskMaster> {

    public TaskMaster getTaskMasterByEmail(String email);

    public TaskMaster saveTaskMaster(TaskMasterVO taskMasterVO);

    public List<TaskMaster> searchByTag(String tag);
}
