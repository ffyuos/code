package com.common;

/**
 * This is enum class for dealing with deal-request api.
 */
public enum ConnectionStatus {
    unresolved(0),
    accepted(1),
    declined(2),
    WRONG(-1);

    public final int statusCode;

    ConnectionStatus(int statusCode) {
        this.statusCode = statusCode;
    }

    public static ConnectionStatus getStatusBy(int id){
        for(ConnectionStatus connectionStatus:ConnectionStatus.values()){
            if(connectionStatus.statusCode == id){
                return connectionStatus;
            }
        }
        return WRONG;
    }


    public int getStatusCode() {
        return statusCode;
    }
}
