package com.common;

/**
 * Class of information to Wrong operations
 */
public enum ValidateInfo {
    SUCCESS(0,"Success"),
    Existing_Email(1,"The email has existed in the system."), // This is for sign
    Account_Not_Exist(2,"The account not existed."),
    Wrong_Password(3,"Wrong Password."),
    Service_Save_Error(4,"Save not Success."),
    Id_NOT_NULL(5,"id should be null."),
    ALREADY_CONNECTED(6,"You have already connected with the task master."),
    WORNG_CONNECT_STATUS_CODE(7, "CONNECT CODE MUST BE 0,1 OR 2"),
    GENERAL_WRONG(8,"General Wrong"),
    ALREADY_SEND_REQUEST(9,"You have already sent a request to the master" ),
    WRONG_TASK_STATUS_CODE(10,"Task status code must be 1 2 3 or 0" ),
    TASK_NOT_EXIST(11,"Task Not exist" ),
    CAN_NOT_UPDATE_COMPLETED_TASK(12, "Can not edit completed tasks"),
    Toolong_Arguments(13, "Length of username,password,tags concatenation should not be more than 20"),
    WORNG_TITLE(14, "Task title can not be null and length of title can not exceed 50"),
    WORNG_TASK_DESCRIPTION(15,"Task description can not be null and length of title can not exceed 50" ),
    WRONG_TASK_TAG(16,"The length of task tag can not exceed 20" ),
    CAN_NOT_CONNECT_YOURSELF(17,"Can not connect yourself" );

    private int code;
    private String info;

    ValidateInfo(int code, String info) {
        this.code = code;
        this.info = info;
    }

    public int getCode() {
        return code;
    }

    public String getInfo() {
        return info;
    }
}
