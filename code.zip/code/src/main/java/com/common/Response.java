package com.common;

import lombok.Data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * This is a standard-common response type
 * @param <Item>
 */
@Data
public class Response<Item> implements Serializable {

    private Integer code;

    private String message;

    private Item data;

    private Map map = new HashMap();

    public static <Item> Response<Item> success(Item item){
        Response<Item> response = new Response<>();
        response.data = item;
        response.code = 0;
        response.message = "success";
        return response;
    }

    public static <Item> Response<Item> success(){
        Response<Item> response = new Response<>();
        response.data = null;
        response.code = 0;
        response.message = "success";
        return response;
    }

    public static <Item> Response<Item> error(String message,int code){
        Response<Item> response = new Response<>();
        response.code = code;
        response.message = message;
        return response;
    }

    public static <Item> Response<Item> error(ValidateInfo validateInfo){
        Response<Item> response = new Response<>();
        response.code = validateInfo.getCode();
        response.message = validateInfo.getInfo();
        return response;
    }

    public static <Item> Response<Item> error(String string){
        Response<Item> response = new Response<>();
        response.code = ValidateInfo.GENERAL_WRONG.getCode();
        response.message = string;
        return response;
    }

    public Response<Item> otherInfo(String key,Object value){
        this.map.put(key,value);
        return this;
    }


}
